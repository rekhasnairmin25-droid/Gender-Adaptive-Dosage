import { Info } from "lucide-react"
import { DISCLAIMER_TEXT } from "@/lib/config"

export function DisclaimerBanner() {
  return (
    <div className="flex gap-3 rounded-lg border border-border bg-muted/50 px-4 py-3 text-sm text-muted-foreground">
      <Info className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
      <p className="leading-relaxed">{DISCLAIMER_TEXT}</p>
    </div>
  )
}
