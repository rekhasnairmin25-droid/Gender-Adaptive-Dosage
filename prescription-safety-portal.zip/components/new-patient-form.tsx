"use client"

import type React from "react"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { createPatient } from "@/app/actions/patients"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export function NewPatientForm({ onDone }: { onDone?: () => void }) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [sex, setSex] = useState<string>("")

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget
    const data = new FormData(form)
    const name = String(data.get("name") ?? "").trim()

    if (!name) {
      toast.error("Patient name is required")
      return
    }
    if (!sex) {
      toast.error("Please select the patient's sex")
      return
    }

    startTransition(async () => {
      try {
        const created = await createPatient({
          name,
          sex,
          dateOfBirth: String(data.get("dateOfBirth") ?? "") || null,
          weightKg: String(data.get("weightKg") ?? "") || null,
          heightCm: String(data.get("heightCm") ?? "") || null,
          knownConditions: String(data.get("knownConditions") ?? "") || null,
        })
        toast.success(`Added ${created.name}`)
        onDone?.()
        router.push(`/patients/${created.id}`)
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Could not create patient")
      }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-4">
      <div className="grid gap-2">
        <Label htmlFor="name">Full name</Label>
        <Input id="name" name="name" placeholder="Jane Doe" autoComplete="off" required />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="grid gap-2">
          <Label htmlFor="sex">Sex</Label>
          <Select value={sex} onValueChange={setSex}>
            <SelectTrigger id="sex">
              <SelectValue placeholder="Select" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="female">Female</SelectItem>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="intersex">Intersex</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            Used to evaluate sex-based dosing warnings.
          </p>
        </div>
        <div className="grid gap-2">
          <Label htmlFor="dateOfBirth">Date of birth</Label>
          <Input id="dateOfBirth" name="dateOfBirth" type="date" />
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="grid gap-2">
          <Label htmlFor="weightKg">Weight (kg)</Label>
          <Input id="weightKg" name="weightKg" type="number" step="0.1" min="0" placeholder="70" />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="heightCm">Height (cm)</Label>
          <Input id="heightCm" name="heightCm" type="number" step="0.1" min="0" placeholder="165" />
        </div>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="knownConditions">Known conditions</Label>
        <Textarea
          id="knownConditions"
          name="knownConditions"
          placeholder="e.g. long QT syndrome, chronic kidney disease"
          rows={2}
        />
      </div>

      <div className="flex justify-end gap-2 pt-1">
        <Button type="submit" disabled={isPending}>
          {isPending ? "Saving..." : "Add patient"}
        </Button>
      </div>
    </form>
  )
}
