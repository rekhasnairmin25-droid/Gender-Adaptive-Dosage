"use client"

import type React from "react"

import { useMemo, useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { AlertTriangle, ShieldCheck } from "lucide-react"
import { createPrescription } from "@/app/actions/prescriptions"
import type { Drug } from "@/lib/db/schema"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

function evidenceTone(strength: string | null) {
  switch ((strength ?? "").toLowerCase()) {
    case "strong":
      return "border-danger/40 bg-danger-muted text-danger"
    case "moderate":
      return "border-warning/50 bg-warning-muted text-warning-foreground"
    default:
      return "border-border bg-muted text-muted-foreground"
  }
}

export function PrescribeForm({
  patientId,
  patientSex,
  drugs,
}: {
  patientId: number
  patientSex: string
  drugs: Drug[]
}) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()

  const [drugId, setDrugId] = useState<string>("")
  const [dose, setDose] = useState("")
  const [frequency, setFrequency] = useState("")
  const [duration, setDuration] = useState("")
  const [acknowledge, setAcknowledge] = useState(false)
  const [overrideReason, setOverrideReason] = useState("")

  const selectedDrug = useMemo(
    () => drugs.find((d) => String(d.id) === drugId) ?? null,
    [drugs, drugId],
  )

  const warningFires = useMemo(() => {
    if (!selectedDrug?.appliesToSex) return false
    return selectedDrug.appliesToSex.toLowerCase() === patientSex.toLowerCase()
  }, [selectedDrug, patientSex])

  function resetForm() {
    setDrugId("")
    setDose("")
    setFrequency("")
    setDuration("")
    setAcknowledge(false)
    setOverrideReason("")
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (!selectedDrug) {
      toast.error("Select a medication first")
      return
    }
    if (warningFires && !acknowledge) {
      toast.error("Acknowledge the warning before prescribing")
      return
    }

    startTransition(async () => {
      try {
        await createPrescription({
          patientId,
          patientSex,
          drugId: selectedDrug.id,
          dose,
          frequency,
          duration,
          overridden: warningFires && acknowledge,
          overrideReason: warningFires ? overrideReason : null,
        })
        toast.success(
          warningFires
            ? `Prescribed ${selectedDrug.name} with acknowledged warning`
            : `Prescribed ${selectedDrug.name}`,
        )
        resetForm()
        router.refresh()
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Could not save prescription")
      }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-5">
      <div className="grid gap-2">
        <Label htmlFor="drug">Medication</Label>
        <Select
          value={drugId}
          onValueChange={(v) => {
            setDrugId(v)
            setAcknowledge(false)
            setOverrideReason("")
          }}
        >
          <SelectTrigger id="drug">
            <SelectValue placeholder="Search the formulary" />
          </SelectTrigger>
          <SelectContent>
            {drugs.map((d) => (
              <SelectItem key={d.id} value={String(d.id)} textValue={d.name}>
                {d.name}
                {d.drugClass ? ` · ${d.drugClass}` : ""}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedDrug && !warningFires && (
        <div className="flex items-start gap-3 rounded-lg border border-primary/30 bg-primary/5 px-4 py-3 text-sm">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
          <p className="text-foreground">
            No sex-based dosing warning on file for {selectedDrug.name} in this patient.
          </p>
        </div>
      )}

      {selectedDrug && warningFires && (
        <div
          role="alert"
          className="grid gap-3 rounded-lg border border-danger/40 bg-danger-muted px-4 py-4"
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-danger" aria-hidden="true" />
            <span className="font-semibold text-danger">Sex-based dosing warning</span>
            {selectedDrug.evidenceStrength && (
              <Badge
                variant="outline"
                className={`ml-auto ${evidenceTone(selectedDrug.evidenceStrength)}`}
              >
                {selectedDrug.evidenceStrength}
              </Badge>
            )}
          </div>

          <div className="grid gap-1 text-sm">
            <p className="font-medium text-foreground">Concern</p>
            <p className="leading-relaxed text-foreground/90">{selectedDrug.warningText}</p>
          </div>

          <div className="grid gap-1 text-sm">
            <p className="font-medium text-foreground">Suggested action</p>
            <p className="leading-relaxed text-foreground/90">
              Consider a sex-adjusted starting dose or an alternative agent, review contraindications,
              and document your reasoning below before proceeding.
            </p>
          </div>

          <div className="mt-1 grid gap-2 rounded-md border border-border bg-card/60 px-3 py-3">
            <div className="flex items-start gap-2.5">
              <Checkbox
                id="acknowledge"
                checked={acknowledge}
                onCheckedChange={(v) => setAcknowledge(v === true)}
                className="mt-0.5"
              />
              <Label htmlFor="acknowledge" className="text-sm font-normal leading-snug">
                I have reviewed this warning and take clinical responsibility for prescribing anyway.
              </Label>
            </div>
            {acknowledge && (
              <Textarea
                value={overrideReason}
                onChange={(e) => setOverrideReason(e.target.value)}
                placeholder="Reason for overriding (optional but recommended)"
                rows={2}
                className="bg-background"
              />
            )}
          </div>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="grid gap-2">
          <Label htmlFor="dose">Dose</Label>
          <Input id="dose" value={dose} onChange={(e) => setDose(e.target.value)} placeholder="e.g. 20 mg" />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="frequency">Frequency</Label>
          <Input
            id="frequency"
            value={frequency}
            onChange={(e) => setFrequency(e.target.value)}
            placeholder="e.g. once daily"
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="duration">Duration</Label>
          <Input
            id="duration"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            placeholder="e.g. 30 days"
          />
        </div>
      </div>

      <div className="flex justify-end">
        <Button type="submit" disabled={isPending || !selectedDrug}>
          {isPending ? "Saving..." : "Prescribe"}
        </Button>
      </div>
    </form>
  )
}
