import Link from "next/link"
import { Activity, Stethoscope } from "lucide-react"

export function AppHeader() {
  return (
    <header className="border-b bg-card">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <Stethoscope className="h-5 w-5" aria-hidden="true" />
          </span>
          <span className="flex flex-col leading-tight">
            <span className="text-sm font-semibold tracking-tight">SafeScript</span>
            <span className="text-xs text-muted-foreground">Sex-aware prescribing support</span>
          </span>
        </Link>
        <nav className="flex items-center gap-1 text-sm">
          <Link
            href="/"
            className="rounded-md px-3 py-2 font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            Patients
          </Link>
          <Link
            href="/activity"
            className="flex items-center gap-1.5 rounded-md px-3 py-2 font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <Activity className="h-4 w-4" aria-hidden="true" />
            Activity log
          </Link>
        </nav>
      </div>
    </header>
  )
}
