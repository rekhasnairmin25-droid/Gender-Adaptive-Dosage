"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { AlertTriangle, ClipboardList, MessageSquarePlus, Pill } from "lucide-react"
import { addSymptomReport } from "@/app/actions/prescriptions"
import type { Drug, Prescription } from "@/lib/db/schema"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

type Row = { prescription: Prescription; drug: Drug }

function formatDate(value: Date | string) {
  const d = typeof value === "string" ? new Date(value) : value
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" })
}

function SymptomComposer({ prescriptionId, patientId }: { prescriptionId: number; patientId: number }) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [text, setText] = useState("")
  const [isPending, startTransition] = useTransition()

  if (!open) {
    return (
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="h-8 gap-1.5 text-muted-foreground"
        onClick={() => setOpen(true)}
      >
        <MessageSquarePlus className="h-4 w-4" aria-hidden="true" />
        Record reported effects
      </Button>
    )
  }

  return (
    <div className="grid gap-2">
      <Textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Patient-reported symptoms or side effects"
        rows={2}
        className="bg-background"
      />
      <div className="flex gap-2">
        <Button
          type="button"
          size="sm"
          disabled={isPending}
          onClick={() => {
            if (!text.trim()) {
              toast.error("Enter the reported effects first")
              return
            }
            startTransition(async () => {
              try {
                await addSymptomReport({ prescriptionId, patientId, text })
                toast.success("Reported effects recorded")
                setText("")
                setOpen(false)
                router.refresh()
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Could not save")
              }
            })
          }}
        >
          {isPending ? "Saving..." : "Save"}
        </Button>
        <Button
          type="button"
          size="sm"
          variant="ghost"
          onClick={() => {
            setOpen(false)
            setText("")
          }}
        >
          Cancel
        </Button>
      </div>
    </div>
  )
}

export function PrescriptionHistory({
  rows,
  patientId,
}: {
  rows: Row[]
  patientId: number
}) {
  if (rows.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed py-12 text-center">
        <ClipboardList className="h-7 w-7 text-muted-foreground" aria-hidden="true" />
        <p className="font-medium">No prescriptions yet</p>
        <p className="text-sm text-muted-foreground">Prescribed medications will appear here.</p>
      </div>
    )
  }

  return (
    <ul className="grid gap-3">
      {rows.map(({ prescription: rx, drug: d }) => (
        <li key={rx.id} className="rounded-lg border bg-card p-4">
          <div className="flex flex-wrap items-start gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-muted text-foreground">
              <Pill className="h-4 w-4" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-medium">{d.name}</span>
                {d.drugClass && (
                  <span className="text-xs text-muted-foreground">{d.drugClass}</span>
                )}
                {rx.warningTriggered && (
                  <Badge
                    variant="outline"
                    className="gap-1 border-danger/40 bg-danger-muted text-danger"
                  >
                    <AlertTriangle className="h-3 w-3" aria-hidden="true" />
                    {rx.overridden ? "Warning overridden" : "Warning flagged"}
                  </Badge>
                )}
              </div>
              <p className="mt-0.5 text-sm text-muted-foreground">
                {[rx.dose, rx.frequency, rx.duration].filter(Boolean).join(" · ") ||
                  "No dosing details recorded"}
              </p>
            </div>
            <span className="text-xs text-muted-foreground">{formatDate(rx.createdAt)}</span>
          </div>

          {rx.overridden && rx.overrideReason && (
            <p className="mt-3 rounded-md border border-warning/40 bg-warning-muted px-3 py-2 text-sm text-warning-foreground">
              <span className="font-medium">Override reason: </span>
              {rx.overrideReason}
            </p>
          )}

          <div className="mt-3 border-t pt-2">
            <SymptomComposer prescriptionId={rx.id} patientId={patientId} />
          </div>
        </li>
      ))}
    </ul>
  )
}
