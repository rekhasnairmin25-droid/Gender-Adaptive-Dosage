"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { ChevronRight, Search, UserRound } from "lucide-react"
import type { Patient } from "@/lib/db/schema"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

function ageFromDob(dob: string | null) {
  if (!dob) return null
  const birth = new Date(dob)
  if (Number.isNaN(birth.getTime())) return null
  const diff = Date.now() - birth.getTime()
  return Math.floor(diff / (365.25 * 24 * 60 * 60 * 1000))
}

export function PatientList({ patients }: { patients: Patient[] }) {
  const [query, setQuery] = useState("")

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return patients
    return patients.filter((p) => p.name.toLowerCase().includes(q))
  }, [patients, query])

  if (patients.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed py-14 text-center">
        <UserRound className="h-8 w-8 text-muted-foreground" aria-hidden="true" />
        <p className="font-medium">No patients yet</p>
        <p className="text-sm text-muted-foreground">
          Add your first patient to start prescribing.
        </p>
      </div>
    )
  }

  return (
    <div className="grid gap-3">
      <div className="relative">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
          aria-hidden="true"
        />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search patients by name"
          className="pl-9"
          aria-label="Search patients"
        />
      </div>

      <ul className="grid gap-2">
        {filtered.map((p) => {
          const age = ageFromDob(p.dateOfBirth)
          return (
            <li key={p.id}>
              <Link
                href={`/patients/${p.id}`}
                className="flex items-center gap-4 rounded-lg border bg-card px-4 py-3 transition-colors hover:border-primary/40 hover:bg-muted/40"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted text-sm font-semibold text-foreground">
                  {p.name.slice(0, 1).toUpperCase()}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium">{p.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {[age != null ? `${age} yrs` : null, p.weightKg ? `${p.weightKg} kg` : null]
                      .filter(Boolean)
                      .join(" · ") || "No demographics on file"}
                  </span>
                </span>
                <Badge variant="secondary" className="shrink-0 capitalize">
                  {p.sex}
                </Badge>
                <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              </Link>
            </li>
          )
        })}
        {filtered.length === 0 && (
          <li className="rounded-lg border border-dashed px-4 py-8 text-center text-sm text-muted-foreground">
            No patients match &ldquo;{query}&rdquo;
          </li>
        )}
      </ul>
    </div>
  )
}
