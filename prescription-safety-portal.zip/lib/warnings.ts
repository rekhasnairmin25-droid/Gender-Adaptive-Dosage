// The warning engine: a rule fires when the patient's sex matches the drug's
// `appliesToSex` value. A pure function so it can be shared by server actions and
// client components without pulling in server-only code.
export function warningFires(patientSex: string, drugAppliesToSex: string | null) {
  if (!drugAppliesToSex) return false
  return patientSex.toLowerCase() === drugAppliesToSex.toLowerCase()
}
