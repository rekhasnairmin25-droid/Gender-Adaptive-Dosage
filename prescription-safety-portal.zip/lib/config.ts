// Auth is deferred for this phase. Every action is attributed to a single seeded
// doctor. When Better Auth is added later, replace reads of this constant with the
// authenticated session's doctor id — the schema already carries doctor_id
// everywhere, so no data migration is required.
export const CURRENT_DOCTOR_ID = 1

export const DISCLAIMER_TEXT =
  "This tool is a decision-support aid to help identify medications with documented sex-based dosing considerations. It is not a substitute for clinical judgment, official prescribing information, or patient-specific evaluation. The prescribing doctor is responsible for the final decision."
