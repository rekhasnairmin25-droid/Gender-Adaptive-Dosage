import {
  boolean,
  date,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core"

// Doctor accounts. A `role` column exists now so pharmacist/patient roles can be
// added in later phases without a schema rewrite. Auth is intentionally deferred,
// so there is no password column yet.
export const doctor = pgTable("doctor", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  licenseNumber: text("license_number"),
  role: text("role").notNull().default("doctor"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

export const patient = pgTable("patient", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  dateOfBirth: date("date_of_birth"),
  sex: text("sex").notNull(),
  weightKg: numeric("weight_kg"),
  heightCm: numeric("height_cm"),
  knownConditions: text("known_conditions"),
  createdByDoctorId: integer("created_by_doctor_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

// The fixed drug list from the brief, stored as structured data so warning rules
// can be updated without touching the UI. A rule fires when a patient's sex
// matches `appliesToSex`.
export const drug = pgTable("drug", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  drugClass: text("drug_class"),
  warningText: text("warning_text"),
  evidenceStrength: text("evidence_strength"),
  appliesToSex: text("applies_to_sex"),
})

export const prescription = pgTable("prescription", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").notNull(),
  doctorId: integer("doctor_id").notNull(),
  drugId: integer("drug_id").notNull(),
  dose: text("dose"),
  frequency: text("frequency"),
  duration: text("duration"),
  warningTriggered: boolean("warning_triggered").notNull().default(false),
  overridden: boolean("overridden").notNull().default(false),
  overrideReason: text("override_reason"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

// Outcome data: patient-reported symptoms or side effects linked to a prescription.
// For this phase these are entered manually by the doctor (the emailed public-link
// flow is planned but not built yet).
export const symptomReport = pgTable("symptom_report", {
  id: serial("id").primaryKey(),
  prescriptionId: integer("prescription_id").notNull(),
  patientSubmittedText: text("patient_submitted_text"),
  source: text("source").notNull().default("doctor"),
  submittedAt: timestamp("submitted_at", { withTimezone: true }).notNull().defaultNow(),
})

// Audit trail of every create/edit/override action.
export const activityLog = pgTable("activity_log", {
  id: serial("id").primaryKey(),
  doctorId: integer("doctor_id").notNull(),
  actionType: text("action_type").notNull(),
  targetId: integer("target_id"),
  details: text("details"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

export type Doctor = typeof doctor.$inferSelect
export type Patient = typeof patient.$inferSelect
export type Drug = typeof drug.$inferSelect
export type Prescription = typeof prescription.$inferSelect
export type SymptomReport = typeof symptomReport.$inferSelect
export type ActivityLog = typeof activityLog.$inferSelect
