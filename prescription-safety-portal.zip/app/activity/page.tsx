import {
  AlertTriangle,
  FileText,
  MessageSquare,
  Pill,
  UserPlus,
} from "lucide-react"
import { getActivityLog } from "@/app/actions/activity"
import { AppHeader } from "@/components/app-header"

function iconFor(actionType: string) {
  switch (actionType) {
    case "create_patient":
      return UserPlus
    case "create_prescription":
      return Pill
    case "override_warning":
      return AlertTriangle
    case "add_symptom_report":
      return MessageSquare
    default:
      return FileText
  }
}

function formatDateTime(value: Date | string) {
  const d = typeof value === "string" ? new Date(value) : value
  return d.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  })
}

export default async function ActivityPage() {
  const entries = await getActivityLog()

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />
      <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold tracking-tight">Activity log</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            An audit trail of patients created, prescriptions written, and warnings overridden.
          </p>
        </div>

        {entries.length === 0 ? (
          <div className="rounded-lg border border-dashed py-14 text-center text-sm text-muted-foreground">
            No activity recorded yet.
          </div>
        ) : (
          <ol className="relative grid gap-1 border-l pl-6">
            {entries.map((entry) => {
              const Icon = iconFor(entry.actionType)
              const isOverride = entry.actionType === "override_warning"
              return (
                <li key={entry.id} className="relative pb-4">
                  <span
                    className={`absolute -left-[33px] flex h-6 w-6 items-center justify-center rounded-full ring-4 ring-background ${
                      isOverride ? "bg-danger-muted text-danger" : "bg-muted text-foreground"
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                  </span>
                  <div className="rounded-lg border bg-card px-4 py-3">
                    <p className="text-sm text-foreground">{entry.details}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {formatDateTime(entry.createdAt)}
                    </p>
                  </div>
                </li>
              )
            })}
          </ol>
        )}
      </main>
    </div>
  )
}
