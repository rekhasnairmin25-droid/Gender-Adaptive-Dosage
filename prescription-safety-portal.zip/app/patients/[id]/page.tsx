import { notFound } from "next/navigation"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { getPatient } from "@/app/actions/patients"
import { getDrugs } from "@/app/actions/drugs"
import { getPrescriptionsForPatient } from "@/app/actions/prescriptions"
import { AppHeader } from "@/components/app-header"
import { PrescribeForm } from "@/components/prescribe-form"
import { PrescriptionHistory } from "@/components/prescription-history"
import { DisclaimerBanner } from "@/components/disclaimer-banner"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

function ageFromDob(dob: string | null) {
  if (!dob) return null
  const birth = new Date(dob)
  if (Number.isNaN(birth.getTime())) return null
  return Math.floor((Date.now() - birth.getTime()) / (365.25 * 24 * 60 * 60 * 1000))
}

export default async function PatientPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const patientId = Number(id)
  if (Number.isNaN(patientId)) notFound()

  const patient = await getPatient(patientId)
  if (!patient) notFound()

  const [drugs, rows] = await Promise.all([
    getDrugs(),
    getPrescriptionsForPatient(patientId),
  ])

  const age = ageFromDob(patient.dateOfBirth)
  const demographics = [
    age != null ? `${age} yrs` : null,
    patient.weightKg ? `${patient.weightKg} kg` : null,
    patient.heightCm ? `${patient.heightCm} cm` : null,
  ].filter(Boolean)

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />
      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        <Link
          href="/"
          className="mb-5 inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          All patients
        </Link>

        <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-muted text-xl font-semibold">
              {patient.name.slice(0, 1).toUpperCase()}
            </span>
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">{patient.name}</h1>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                <Badge variant="secondary" className="capitalize">
                  {patient.sex}
                </Badge>
                {demographics.length > 0 && <span>{demographics.join(" · ")}</span>}
              </div>
            </div>
          </div>
        </div>

        {patient.knownConditions && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-sm text-muted-foreground">Known conditions</CardTitle>
            </CardHeader>
            <CardContent className="text-sm leading-relaxed">{patient.knownConditions}</CardContent>
          </Card>
        )}

        <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
          <section aria-label="New prescription">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">New prescription</CardTitle>
              </CardHeader>
              <CardContent>
                <PrescribeForm patientId={patient.id} patientSex={patient.sex} drugs={drugs} />
              </CardContent>
            </Card>
            <div className="mt-4">
              <DisclaimerBanner />
            </div>
          </section>

          <section aria-label="Prescription history" className="grid gap-3">
            <h2 className="text-base font-semibold">Prescription history</h2>
            <PrescriptionHistory rows={rows} patientId={patient.id} />
          </section>
        </div>
      </main>
    </div>
  )
}
